#!/bin/bash
TOOLS_DIR=`dirname $0`
$TOOLS_DIR/runTool.sh $TOOLS_DIR/hibDownload/build/libs/hibDownload.jar "$@"